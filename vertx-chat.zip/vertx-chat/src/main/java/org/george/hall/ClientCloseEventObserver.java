package org.george.hall;

public interface ClientCloseEventObserver {

    void clientCloseNotify(String hId);
}
