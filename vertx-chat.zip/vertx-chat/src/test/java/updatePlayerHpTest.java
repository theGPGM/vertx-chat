import org.junit.Test;

public class updatePlayerHpTest {

    @Test
    public void updatePlayerHp(){
        int increment = (int) (System.currentTimeMillis() - 1609215187689l) / (1000 * 60 * 5);
        System.out.println(increment);
    }
}
